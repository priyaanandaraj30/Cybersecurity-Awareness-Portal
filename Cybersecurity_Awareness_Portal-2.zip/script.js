const answers = document.querySelectorAll('.answer');
const result = document.getElementById('quiz-result');

answers.forEach(answer => {
  answer.addEventListener('click', () => {
    if (answer.classList.contains('correct')) {
      result.textContent = 'Correct! Always verify suspicious links before clicking.';
      result.style.color = '#2dd4bf';
    } else {
      result.textContent = 'Try again. Do not click suspicious links without verifying them.';
      result.style.color = '#f59e0b';
    }
  });
});
